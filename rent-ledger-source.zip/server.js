const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const os = require("os");

const app = express();
const PORT = process.env.PORT || 4000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");
const DB_PATH = path.join(DATA_DIR, "db.json");
const SEED_DB_PATH = path.join(__dirname, "data", "db.json");

app.use(express.json());
// Browser clients use the same HTTPS origin in production. A native mobile wrapper can
// be allowed explicitly with CORS_ORIGINS, rather than exposing the API to every origin.
app.use((req, res, next) => {
  const origin = req.headers.origin;
  const allowed = (process.env.CORS_ORIGINS || '').split(',').map(v => v.trim()).filter(Boolean);
  if (origin && allowed.includes(origin)) res.setHeader('Access-Control-Allow-Origin', origin);
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});
app.use(express.static(path.join(__dirname, "public")));

// ---------- tiny JSON-file datastore ----------

function emptyDb() {
  return {
    users: [],
    buildings: [],
    rooms: [],
    tenants: [],
    rentEntries: [],
    electricityEntries: [],
  };
}

const sessions = new Map();
function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  return { passwordSalt: salt, passwordHash: crypto.scryptSync(password, salt, 64).toString('hex') };
}
function validPassword(user, password) {
  // Existing local users are upgraded after their next successful login.
  if (!user.passwordSalt) return user.passwordHash === crypto.createHash('sha256').update(password).digest('hex');
  const candidate = crypto.scryptSync(password, user.passwordSalt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(candidate, 'hex'), Buffer.from(user.passwordHash, 'hex'));
}
function safeUser(user) { return { id: user.id, name: user.name, role: user.role, tenantId: user.tenantId || null }; }
function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  const userId = sessions.get(token);
  const user = loadDb().users?.find(u => u.id === userId);
  if (!user) return res.status(401).json({ error: 'Please sign in to continue' });
  req.user = user; next();
}

// ---------- Login / role accounts ----------
app.post('/api/auth/signup', (req, res) => {
  const db = loadDb();
  db.users = db.users || [];
  const { name, contact, password, role } = req.body;
  if (!name || !contact || !password || !['owner', 'tenant'].includes(role)) return res.status(400).json({ error: 'Name, contact, password and role are required' });
  if (db.users.some(u => u.contact.toLowerCase() === String(contact).toLowerCase())) return res.status(409).json({ error: 'An account with this contact already exists' });
  if (role === 'owner' && db.users.some(u => u.role === 'owner')) return res.status(403).json({ error: 'Owner accounts are created during initial setup only' });
  let tenantId = null;
  if (role === 'tenant') {
    const tenant = db.tenants.find(t => t.active && t.mobile.replace(/\D/g, '') === String(contact).replace(/\D/g, ''));
    if (!tenant) return res.status(400).json({ error: 'This mobile number is not linked to an active tenant record. Ask your owner to add you first.' });
    tenantId = tenant.id;
  }
  const user = { id: id(), name, contact, ...hashPassword(password), role, tenantId, createdAt: new Date().toISOString() };
  db.users.push(user); saveDb(db);
  const token = id(); sessions.set(token, user.id);
  res.status(201).json({ token, user: safeUser(user) });
});

app.post('/api/auth/login', (req, res) => {
  const db = loadDb(); const { contact, password } = req.body;
  const user = (db.users || []).find(u => u.contact.toLowerCase() === String(contact || '').toLowerCase() && validPassword(u, password || ''));
  if (!user) return res.status(401).json({ error: 'Incorrect contact or password' });
  if (!user.passwordSalt) Object.assign(user, hashPassword(password));
  saveDb(db);
  const token = id(); sessions.set(token, user.id);
  res.json({ token, user: safeUser(user) });
});

app.get('/api/tenant/portal', auth, (req, res) => {
  if (req.user.role !== 'tenant') return res.status(403).json({ error: 'Tenant account required' });
  const db = loadDb(); const tenant = db.tenants.find(t => t.id === req.user.tenantId && t.active);
  if (!tenant) return res.status(404).json({ error: 'No active tenancy found' });
  const room = db.rooms.find(r => r.id === tenant.roomId);
  const building = db.buildings.find(b => b.id === room?.buildingId);
  const rent = db.rentEntries.filter(e => e.roomId === room.id).sort((a,b) => b.year-a.year || b.month-a.month);
  const electricity = db.electricityEntries.filter(e => e.roomId === room.id).sort((a,b) => b.year-a.year || b.month-a.month);
  res.json({ tenant: { name: tenant.name }, room: { label: room.label, floorNumber: room.floorNumber, monthlyRent: room.monthlyRent }, building: { name: building?.name || '' }, rent, electricity });
});

// All management endpoints below are owner-only. Tenant accounts can only read their portal.
app.use('/api', auth, (req, res, next) => {
  if (req.user.role !== 'owner') return res.status(403).json({ error: 'Owner account required' });
  next();
});

function loadDb() {
  if (!fs.existsSync(DB_PATH)) {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    if (DB_PATH !== SEED_DB_PATH && fs.existsSync(SEED_DB_PATH)) fs.copyFileSync(SEED_DB_PATH, DB_PATH);
    else fs.writeFileSync(DB_PATH, JSON.stringify(emptyDb(), null, 2));
  }
  return JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
}

function saveDb(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

function id() {
  return crypto.randomUUID();
}

function notFound(res, what) {
  return res.status(404).json({ error: `${what} not found` });
}

// Recompute a room's occupied/vacant status from its active tenants.
function refreshRoomStatus(db, roomId) {
  const room = db.rooms.find((r) => r.id === roomId);
  if (!room) return;
  const hasActiveTenant = db.tenants.some((t) => t.roomId === roomId && t.active);
  room.status = hasActiveTenant ? "occupied" : "vacant";
}

// ---------- Buildings ----------

app.get("/api/buildings", (req, res) => {
  const db = loadDb();
  res.json(db.buildings);
});

app.post("/api/buildings", (req, res) => {
  const db = loadDb();
  const { name, address, totalFloors, notes } = req.body;
  if (!name) return res.status(400).json({ error: "name is required" });
  const building = {
    id: id(),
    name,
    address: address || "",
    totalFloors: Number(totalFloors) || 0,
    notes: notes || "",
    createdAt: new Date().toISOString(),
  };
  db.buildings.push(building);
  saveDb(db);
  res.status(201).json(building);
});

app.put("/api/buildings/:id", (req, res) => {
  const db = loadDb();
  const building = db.buildings.find((b) => b.id === req.params.id);
  if (!building) return notFound(res, "Building");
  Object.assign(building, req.body, { id: building.id });
  if (building.totalFloors !== undefined) building.totalFloors = Number(building.totalFloors) || 0;
  saveDb(db);
  res.json(building);
});

app.delete("/api/buildings/:id", (req, res) => {
  const db = loadDb();
  const roomIds = db.rooms.filter((r) => r.buildingId === req.params.id).map((r) => r.id);
  db.rooms = db.rooms.filter((r) => r.buildingId !== req.params.id);
  db.tenants = db.tenants.filter((t) => !roomIds.includes(t.roomId));
  db.rentEntries = db.rentEntries.filter((e) => !roomIds.includes(e.roomId));
  db.electricityEntries = db.electricityEntries.filter((e) => !roomIds.includes(e.roomId));
  db.buildings = db.buildings.filter((b) => b.id !== req.params.id);
  saveDb(db);
  res.json({ ok: true });
});

// ---------- Rooms (floor / room units within a building) ----------

app.get("/api/rooms", (req, res) => {
  const db = loadDb();
  let rooms = db.rooms;
  if (req.query.buildingId) rooms = rooms.filter((r) => r.buildingId === req.query.buildingId);
  res.json(rooms);
});

app.post("/api/rooms", (req, res) => {
  const db = loadDb();
  const { buildingId, floorNumber, label, monthlyRent, deposit, notes } = req.body;
  if (!buildingId || !label) return res.status(400).json({ error: "buildingId and label are required" });
  if (!db.buildings.find((b) => b.id === buildingId)) return notFound(res, "Building");
  const room = {
    id: id(),
    buildingId,
    floorNumber: Number(floorNumber) || 0,
    label,
    monthlyRent: Number(monthlyRent) || 0,
    deposit: Number(deposit) || 0,
    status: "vacant",
    notes: notes || "",
    createdAt: new Date().toISOString(),
  };
  db.rooms.push(room);
  saveDb(db);
  res.status(201).json(room);
});

app.put("/api/rooms/:id", (req, res) => {
  const db = loadDb();
  const room = db.rooms.find((r) => r.id === req.params.id);
  if (!room) return notFound(res, "Room");
  Object.assign(room, req.body, { id: room.id });
  if (room.monthlyRent !== undefined) room.monthlyRent = Number(room.monthlyRent) || 0;
  if (room.deposit !== undefined) room.deposit = Number(room.deposit) || 0;
  if (room.floorNumber !== undefined) room.floorNumber = Number(room.floorNumber) || 0;
  saveDb(db);
  res.json(room);
});

app.delete("/api/rooms/:id", (req, res) => {
  const db = loadDb();
  db.tenants = db.tenants.filter((t) => t.roomId !== req.params.id);
  db.rentEntries = db.rentEntries.filter((e) => e.roomId !== req.params.id);
  db.electricityEntries = db.electricityEntries.filter((e) => e.roomId !== req.params.id);
  db.rooms = db.rooms.filter((r) => r.id !== req.params.id);
  saveDb(db);
  res.json({ ok: true });
});

// ---------- Tenants ----------

app.get("/api/tenants", (req, res) => {
  const db = loadDb();
  let tenants = db.tenants;
  if (req.query.roomId) tenants = tenants.filter((t) => t.roomId === req.query.roomId);
  res.json(tenants);
});

app.post("/api/tenants", (req, res) => {
  const db = loadDb();
  const {
    roomId, name, mobile, altMobile, email,
    idProofType, idProofNumber, moveInDate, notes,
  } = req.body;
  if (!roomId || !name || !mobile) {
    return res.status(400).json({ error: "roomId, name and mobile are required" });
  }
  const room = db.rooms.find((r) => r.id === roomId);
  if (!room) return notFound(res, "Room");

  const tenant = {
    id: id(),
    roomId,
    name,
    mobile,
    altMobile: altMobile || "",
    email: email || "",
    idProofType: idProofType || "",
    idProofNumber: idProofNumber || "",
    moveInDate: moveInDate || "",
    moveOutDate: "",
    active: true,
    notes: notes || "",
    createdAt: new Date().toISOString(),
  };
  db.tenants.push(tenant);
  refreshRoomStatus(db, roomId);
  saveDb(db);
  res.status(201).json(tenant);
});

app.put("/api/tenants/:id", (req, res) => {
  const db = loadDb();
  const tenant = db.tenants.find((t) => t.id === req.params.id);
  if (!tenant) return notFound(res, "Tenant");
  Object.assign(tenant, req.body, { id: tenant.id });
  refreshRoomStatus(db, tenant.roomId);
  saveDb(db);
  res.json(tenant);
});

// Mark tenant as moved out (keeps history, frees the room)
app.post("/api/tenants/:id/move-out", (req, res) => {
  const db = loadDb();
  const tenant = db.tenants.find((t) => t.id === req.params.id);
  if (!tenant) return notFound(res, "Tenant");
  tenant.active = false;
  tenant.moveOutDate = req.body.moveOutDate || new Date().toISOString().slice(0, 10);
  refreshRoomStatus(db, tenant.roomId);
  saveDb(db);
  res.json(tenant);
});

app.delete("/api/tenants/:id", (req, res) => {
  const db = loadDb();
  const tenant = db.tenants.find((t) => t.id === req.params.id);
  db.tenants = db.tenants.filter((t) => t.id !== req.params.id);
  if (tenant) refreshRoomStatus(db, tenant.roomId);
  saveDb(db);
  res.json({ ok: true });
});

// ---------- Rent entries ----------

app.get("/api/rent", (req, res) => {
  const db = loadDb();
  let entries = db.rentEntries;
  if (req.query.roomId) entries = entries.filter((e) => e.roomId === req.query.roomId);
  if (req.query.tenantId) entries = entries.filter((e) => e.tenantId === req.query.tenantId);
  if (req.query.buildingId) {
    const roomIds = db.rooms.filter((r) => r.buildingId === req.query.buildingId).map((r) => r.id);
    entries = entries.filter((e) => roomIds.includes(e.roomId));
  }
  res.json(entries);
});

app.post("/api/rent", (req, res) => {
  const db = loadDb();
  const { roomId, tenantId, month, year, rentAmount, amountPaid, dueDate, paidDate, notes } = req.body;
  if (!roomId || !month || !year) return res.status(400).json({ error: "roomId, month and year are required" });
  const paid = Number(amountPaid) || 0;
  const due = Number(rentAmount) || 0;
  const entry = {
    id: id(),
    roomId,
    tenantId: tenantId || null,
    month: Number(month),
    year: Number(year),
    rentAmount: due,
    amountPaid: paid,
    dueDate: dueDate || "",
    paidDate: paidDate || "",
    status: paid <= 0 ? "due" : paid < due ? "partial" : "paid",
    notes: notes || "",
    createdAt: new Date().toISOString(),
  };
  db.rentEntries.push(entry);
  saveDb(db);
  res.status(201).json(entry);
});

app.put("/api/rent/:id", (req, res) => {
  const db = loadDb();
  const entry = db.rentEntries.find((e) => e.id === req.params.id);
  if (!entry) return notFound(res, "Rent entry");
  Object.assign(entry, req.body, { id: entry.id });
  entry.rentAmount = Number(entry.rentAmount) || 0;
  entry.amountPaid = Number(entry.amountPaid) || 0;
  entry.status = entry.amountPaid <= 0 ? "due" : entry.amountPaid < entry.rentAmount ? "partial" : "paid";
  saveDb(db);
  res.json(entry);
});

app.delete("/api/rent/:id", (req, res) => {
  const db = loadDb();
  db.rentEntries = db.rentEntries.filter((e) => e.id !== req.params.id);
  saveDb(db);
  res.json({ ok: true });
});

// ---------- Electricity entries ----------

app.get("/api/electricity", (req, res) => {
  const db = loadDb();
  let entries = db.electricityEntries;
  if (req.query.roomId) entries = entries.filter((e) => e.roomId === req.query.roomId);
  if (req.query.tenantId) entries = entries.filter((e) => e.tenantId === req.query.tenantId);
  if (req.query.buildingId) {
    const roomIds = db.rooms.filter((r) => r.buildingId === req.query.buildingId).map((r) => r.id);
    entries = entries.filter((e) => roomIds.includes(e.roomId));
  }
  res.json(entries);
});

app.post("/api/electricity", (req, res) => {
  const db = loadDb();
  const {
    roomId, tenantId, month, year,
    prevReading, currReading, ratePerUnit,
    paidDate, notes,
  } = req.body;
  if (!roomId || !month || !year) return res.status(400).json({ error: "roomId, month and year are required" });
  const prev = Number(prevReading) || 0;
  const curr = Number(currReading) || 0;
  const rate = Number(ratePerUnit) || 0;
  const units = Math.max(curr - prev, 0);
  const entry = {
    id: id(),
    roomId,
    tenantId: tenantId || null,
    month: Number(month),
    year: Number(year),
    prevReading: prev,
    currReading: curr,
    unitsConsumed: units,
    ratePerUnit: rate,
    amount: Math.round(units * rate * 100) / 100,
    paidDate: paidDate || "",
    status: paidDate ? "paid" : "due",
    notes: notes || "",
    createdAt: new Date().toISOString(),
  };
  db.electricityEntries.push(entry);
  saveDb(db);
  res.status(201).json(entry);
});

app.put("/api/electricity/:id", (req, res) => {
  const db = loadDb();
  const entry = db.electricityEntries.find((e) => e.id === req.params.id);
  if (!entry) return notFound(res, "Electricity entry");
  Object.assign(entry, req.body, { id: entry.id });
  entry.prevReading = Number(entry.prevReading) || 0;
  entry.currReading = Number(entry.currReading) || 0;
  entry.ratePerUnit = Number(entry.ratePerUnit) || 0;
  entry.unitsConsumed = Math.max(entry.currReading - entry.prevReading, 0);
  entry.amount = Math.round(entry.unitsConsumed * entry.ratePerUnit * 100) / 100;
  entry.status = entry.paidDate ? "paid" : "due";
  saveDb(db);
  res.json(entry);
});

app.delete("/api/electricity/:id", (req, res) => {
  const db = loadDb();
  db.electricityEntries = db.electricityEntries.filter((e) => e.id !== req.params.id);
  saveDb(db);
  res.json({ ok: true });
});

// ---------- Dashboard summary ----------

app.get("/api/dashboard", (req, res) => {
  const db = loadDb();
  const totalBuildings = db.buildings.length;
  const totalRooms = db.rooms.length;
  const occupiedRooms = db.rooms.filter((r) => r.status === "occupied").length;
  const vacantRooms = totalRooms - occupiedRooms;

  const now = new Date();
  const month = now.getMonth() + 1;
  const year = now.getFullYear();

  const rentThisMonth = db.rentEntries.filter((e) => e.month === month && e.year === year);
  const rentCollected = rentThisMonth.reduce((s, e) => s + e.amountPaid, 0);
  const rentPending = rentThisMonth.reduce((s, e) => s + Math.max(e.rentAmount - e.amountPaid, 0), 0);

  const elecThisMonth = db.electricityEntries.filter((e) => e.month === month && e.year === year);
  const elecPending = elecThisMonth.filter((e) => e.status !== "paid").reduce((s, e) => s + e.amount, 0);
  const elecCollected = elecThisMonth.filter((e) => e.status === "paid").reduce((s, e) => s + e.amount, 0);

  const allDueRent = db.rentEntries.filter((e) => e.status !== "paid").length;
  const allDueElec = db.electricityEntries.filter((e) => e.status !== "paid").length;

  res.json({
    totalBuildings,
    totalRooms,
    occupiedRooms,
    vacantRooms,
    month,
    year,
    rentCollected,
    rentPending,
    elecCollected,
    elecPending,
    outstandingRentEntries: allDueRent,
    outstandingElectricityEntries: allDueElec,
  });
});

// Fallback to the SPA for any non-API route
app.get(/^\/(?!api\/).*/, (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, '0.0.0.0', () => {
  const addresses = Object.values(os.networkInterfaces()).flat().filter(info => info && info.family === 'IPv4' && !info.internal).map(info => info.address);
  console.log(`Rent Ledger on this Mac: http://localhost:${PORT}`);
  addresses.forEach(address => console.log(`Open on phone or another computer: http://${address}:${PORT}`));
});
